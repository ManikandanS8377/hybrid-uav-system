#include "RcInput.h"
#include "Debug.h"
#include <WiFi.h>
#include <PubSubClient.h>

// Use extern to reference global clients defined elsewhere (e.g. MqttManager.cpp)
extern WiFiClient wifiClient;
extern PubSubClient mqttClient;

// External failsafe timestamp (declared in main.cpp)
extern unsigned long lastRcUpdate;

void RcInput::begin() {
    // Configure MQTT server + callback
    mqttClient.setServer("broker.emqx.io", 1883);
    mqttClient.setCallback([this](char* topic, byte* payload, unsigned int length) {
        char buf[128];
        if (length >= sizeof(buf)) {
            Debug::logln("[RcInput] Payload too long, ignoring");
            return;
        }
        strncpy(buf, (char*)payload, length);
        buf[length] = '\0';

        this->process(buf);
        lastRcUpdate = micros();
    });
}

void RcInput::updateConnection() {
    // Non-blocking WiFi reconnect
    if (WiFi.status() != WL_CONNECTED) {
        WiFi.begin("yourSSID", "yourPASS");
        return;
    }

    // Non-blocking MQTT reconnect
    if (!mqttClient.connected()) {
        if (mqttClient.connect("esp32_client")) {
            mqttClient.subscribe("espfc/rc");
            Debug::logln("[RcInput] MQTT connected + subscribed");
        }
    }

    // Process incoming packets
    mqttClient.loop();
}

void RcInput::process(const char* payload) {
    valid = false;

    int idx = 0;
    char buf[128];
    strncpy(buf, payload, sizeof(buf));
    buf[sizeof(buf)-1] = '\0';

    char* token = strtok(buf, ",");
    while (token != nullptr && idx < CHANNELS) {
        channels[idx] = atoi(token);
        idx++;
        token = strtok(nullptr, ",");
    }

    if (idx == CHANNELS) {
        valid = true;
        Debug::log("[RcInput] Frame OK: ");
        Debug::logln(payload);
    } else {
        Debug::log("[RcInput] Frame ERR: ");
        Debug::logln(payload);
    }
}

bool RcInput::isValid() {
    return valid;
}

int RcInput::get(int ch) {
    if (ch < 0 || ch >= CHANNELS) return 1500; // safe default
    return channels[ch];
}
